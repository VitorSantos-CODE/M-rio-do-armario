extends Node


var score = 0
var players_dead = 0
var score_at_level_start = 0

func _ready() -> void:
	
	
	
	pass

func _process(delta: float) -> void:
	
	
	
	pass
