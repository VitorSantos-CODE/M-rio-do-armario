extends Camera2D

@onready var player1 = $"../Player"
@onready var player2 = $"../Player2"

func _physics_process(delta: float) -> void:
	
	var pos1 = player1.global_position if (is_instance_valid(player1) and player1.is_alive) else global_position
	var pos2 = player2.global_position if (is_instance_valid(player2) and player2.is_alive) else global_position
	
	var meio = (pos1 + pos2) / 2
	global_position = meio
	
	pass
