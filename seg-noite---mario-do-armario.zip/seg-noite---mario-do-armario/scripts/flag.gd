extends Area2D

@export var next_level: PackedScene

var players_in_area = 0

func _ready() -> void:
	pass


func _process(delta: float) -> void:
	pass


func _on_area_entered(area: Area2D) -> void:
	
	if area.get_parent().is_in_group("Player"):
		players_in_area += 1
		var players_needed = 2 - Global.players_dead
		if players_in_area >= players_needed:
			get_tree().call_deferred("change_scene_to_packed" , next_level)
	
	pass


func _on_area_exited(area: Area2D) -> void:
	
	if area.get_parent().is_in_group("Player"):
		players_in_area -= 1
	
	pass
