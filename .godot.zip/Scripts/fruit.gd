extends Area2D

func _ready() -> void:
	
	
	
	pass


func _process(delta: float) -> void:
	
	
	
	pass


func _on_area_entered(area: Area2D) -> void:
	if area.get_parent().is_in_group("player"):
		var player = area.get_parent()
		
		$AnimatedSprite2D.play("colect")
		$CollisionShape2D.queue_free()
		
		Global.score += 1
		player.extra_jumps += 1
		
		await get_tree().create_timer(1).timeout
		queue_free()
	pass
