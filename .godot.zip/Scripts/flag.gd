extends Area2D
@export var next_level: PackedScene



func _on_area_entered(area: Area2D) -> void:
	
	
	pass # Replace with function body.
