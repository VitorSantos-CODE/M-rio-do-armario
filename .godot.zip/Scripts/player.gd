extends CharacterBody2D

var speed = 160
var jump_velocity =-360
var dir = 0
var gravity = 980 #valor pafrão da gravidade em jogos
var extra_jumps=1
var total_jumps = 1
@onready var anim = $AnimatedSprite2D
@onready var death_line= $"../DeathLine"
var is_alive=true

func _ready() -> void:
	
	
	pass

func _physics_process(delta: float) -> void:
	if is_alive:
		animations()
	move(delta)
	death_test()
	pass


func move (delta):
	
	
	
	if is_alive:
		dir= Input.get_axis("Left","Right")
	if dir:
		velocity.x=dir*speed
	elif dir==0:
		velocity.x=0
	if not is_on_floor(): #se não tiver no chão ele ativa a gravidade
		velocity.y+=gravity*delta
	if Input.is_action_just_pressed("Jump") and extra_jumps>0 and is_alive:
		velocity.y=jump_velocity
		if extra_jumps>0:
			extra_jumps-=1
	if is_on_floor():
		extra_jumps=total_jumps
		
	move_and_slide()#função que movimenta o personagem
	
	pass

func animations():
	
	if velocity.x != 0 and is_on_floor():
		anim.play("run")
	elif velocity.x == 0 and is_on_floor():
		anim.play("idle")
		
	if not is_on_floor() and extra_jumps >= 1: 
		anim.play("jump")
	
	if dir > 0:
		anim.flip_h = false
	elif dir < 0:
		anim.flip_h = true
	
	pass
	
func death_test():
		if global_position.y >= death_line.global_position.y and is_alive:
			die() 
	
func die():
	is_alive=false
	anim.play("hit")
	$AnimatedSprite2D.queue_free()
	$Area2D/CollisionShape2D.queue_free()
	velocity.y = jump_velocity - 100
	
	await get_tree().create_timer(1).timeout
	
	get_tree().reload_current_scene()
	
	pass
func camera_zoom():
	var zoom =2.0
	var new_zoom=3.5
	
	$Camera2D.zoom=Vector2(new_zoom,new_zoom)
	Engine.time_scale=0.5
	
	await get_tree().create_timer(0.8).timeout
	
	$Camera2D.zoom = Vector2(zoom,zoom)
	Engine.time_scale = 1
	
	
