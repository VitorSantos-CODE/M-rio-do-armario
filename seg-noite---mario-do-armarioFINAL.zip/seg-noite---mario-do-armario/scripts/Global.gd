extends Node


var score = 0

func _ready() -> void:
	
	
	
	pass

func _process(delta: float) -> void:
	
	
	
	pass
