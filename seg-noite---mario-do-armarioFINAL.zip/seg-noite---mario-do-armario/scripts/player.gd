extends CharacterBody2D

var speed = 160.0
var dir

var jump_velocity = -300.0
var gravity = 980

var extra_jumps = 1

@onready var anim = $AnimatedSprite2D

var is_alive = true

func _ready() -> void:
	
	
	
	
	pass

func _physics_process(delta: float) -> void:
	
	move(delta)
	
	if is_alive:
		animations()
	
	pass

func move(delta):
	
	if is_alive:
		dir = Input.get_axis("Left" , "Right")
	
	if dir:
		velocity.x = dir * speed
	elif dir == 0:
		velocity.x = 0
	
	if not is_on_floor():
		velocity.y += gravity * delta
	
	if Input.is_action_just_pressed("Jump") and extra_jumps > 0 and is_alive:
		velocity.y = jump_velocity
		if extra_jumps > 0:
			extra_jumps -= 1
	
	if is_on_floor():
		extra_jumps = 1
	
	move_and_slide()
	
	pass
	
func animations():
	
	if velocity.x != 0 and is_on_floor():
		anim.play("Run")
	elif velocity.x == 0 and is_on_floor():
		anim.play("Idle")
		
	if not is_on_floor() and extra_jumps >= 1: 
		anim.play("Jump")
	
	if dir > 0:
		anim.flip_h = false
	elif dir < 0:
		anim.flip_h = true
	
	pass
	
func die():
	
	is_alive = false
	anim.play("Hit")
	
	# Deleta o colisor, fazendo o personagem passar pelo chão
	$CollisionShape2D.queue_free()
	# tira o colisor da área
	$Area2D/CollisionShape2D
	# pula ao levar o hit
	velocity.y = jump_velocity - 100
	
	await get_tree().create_timer(1).timeout
	
	get_tree().reload_current_scene()
	
	pass
